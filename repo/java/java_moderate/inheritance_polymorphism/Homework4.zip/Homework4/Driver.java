
import java.util.*;
import java.lang.*;



/**
 * Created by Tiago Moore on Mar 24, 2014. Copyright (c) 2013 __TiagoMoore__. All rights reserved.
 *
 */
/**
 * A test class to test the Shapes abstract class
 */
public class Driver
{

  public static void main(String[] args)
  {
    // declare an array of shapres
    Shape allShapes[] = new Shape[4];

    //hard code data into array
    allShapes[0] = new Sphere(2, -5, 8, 13);
    allShapes[1] = new Parallelepiped(7, 9, 2, 37, 12, 9);
    allShapes[2] = new Cylinder(3, 4, -5, 11, 13);
    allShapes[3] = new Cone(-5, -2, 1, 10, 14);


    // print data for all shapes in array
    for (int i = 0; i < 4; i++)
    {
      System.out.printf(allShapes[i].toString()
        + ", Area: %.2f, Volume : %.2f%n", allShapes[i].getSA(), allShapes[i].getVolume());
    }
      
      System.out.println("-----------------------------------------------------");


    //Comparator VolumeCompare  = new CompareShape();
    // sorts array in ascending order by the volume using comparator class
  
    Arrays.sort(allShapes, new CompareShape());
    System.out.println("After calling to sort method to sort the shapes in ascending order by volume...");
      
    for (int i = 0; i < 4; i++)
    {
      System.out.print(allShapes[i].getClass()); // get class name ONLY
      System.out.printf(" Volume : %.2f%n", allShapes[i].getVolume());// print volume
    }
      
    System.out.println("-----------------------------------------------------");


    // sorts all shapes by differece from center in dscending order
    Arrays.sort(allShapes);
    System.out.println("After calling to sort method to sort the shapes in descending order by distance from the origin...");

    for (int i = 0; i < 4; i++)
    {
      System.out.print(allShapes[i].getClass()); // get class name ONLY
      
      //print Difference from center
      System.out.printf(" Difference from center: %d%n", allShapes[i].DifferenceFromOrigin());
    }



  }


}
