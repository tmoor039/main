
/**
 *Created by Tiago Moore on Mar 23, 2014.
 *  Copyright (c) 2013 __TiagoMoore__. All rights reserved.
 * 
 */

/**
 * A class to represent a cone object that extends a Shape
 */
public class Cone extends Shape
{

    private double height;
    private double radius;
    
  /**
   * Constructor initializes  all variales
   * @param x the x coordinate
   * @param y the y coordinate
   * @param z the z coordinate
   * @param h the height of the Cone
   * @param r the radius of the Cone
   */
  public Cone(double x, double y, double z, double h, double r )
  {
     super(x, y, z); // calls the super constructor for a Shape
     height = h; // initialies the height 
     radius = r; // initialies the radius
    
  }
  
  /**
   * Computes the surface area of a Cone
   * @return  the surface area of a Cone
   */
  public double getSA()
  {
    return Math.PI*radius*(radius + Math.sqrt((Math.pow(height, 2)+Math.pow(radius, 2))));
  }


/**
 * Computes the volume of a Cone
 * @return  the volume of a Cone
 */
  public double getVolume()
  { 
   return (Math.PI*Math.pow(radius, 2)*height)/3.0;
    
  }


/**
 * Overides the tostring to print all relevant object data
 * @return the values of the cone object
 */
public String toString()
{
  return "Cone with a center of "+super.toString()+ ", Height: " + height+", Radius:  "+radius ;
}


  
}
