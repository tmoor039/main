
/**
 *Created by Tiago Moore on Mar 23, 2014.
 *  Copyright (c) 2013 __TiagoMoore__. All rights reserved.
 * 
 */

/**
 * A class to represent a sphere that extends a shape
 */
public class Sphere extends Shape 
{
    //instance variables
    private double radius;
    
    public Sphere(double x,double y, double z, double r)
    {
      super(x, y, z); // call constructor for the super class 
      radius = r;// initialize spheres instance variable
    }
  
  
/**
 * Computes the surface area of a sphere
 * @return the surface area of a sphere
 */
  public double getSA()
  {
    
    return  4.0*Math.PI*Math.pow(radius, 2); 
  }


 /**
  * Computes the Volume of a Sphere
  * @return  the volume of a sphere
  */
  public double getVolume()
  {
      
    return (4.0/3.0)*Math.PI*Math.pow(radius, 3);
    
  }

  /**
   * Prints coordinates, name and readius by calling superclass tostring
   * @return a string with all the objects dat
   */
  public String toString()
  {
      return "Shpere with a center of "+super.toString()+", Radius:  "+radius;
            
  }
  
  
}
