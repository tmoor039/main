
/**
 *Created by Tiago Moore on Mar 23, 2014.
 *  Copyright (c) 2013 __TiagoMoore__. All rights reserved.
 * 
 */

import java.lang.Math;

/**
 * A class to represent a 3D Shape implements Comparable Interface
 */
public abstract class Shape implements Comparable<Shape>
{
  //instance variables
  private Point3D center; // the center of a shape 
  
  /**
   * Constructor for a SHape initializes the center
   */
  public Shape(double x, double y, double z)
  {
    center = new Point3D(x,y,z);
  }
  
  
  /**
   * Overrides toString to return a string containing
   * the coordinates of the center
   * @return the center
   */
  public String toString()
  {
    return center.toString();
  }

  /**
   * Applies the formula distance = sqrt(x^2+y^2+z^2)
   * to calculate the distance of the point from the origin
   * @return  distance the distance from the origin
   */
  public int DifferenceFromOrigin()
  {
    // dummy variables to hold each coordinate
     double distance = 0 , x = 0 , y = 0 , z = 0 ; 
     
     // square each coordinate
     x = Math.pow(center.getXCoordinate(),2);
     y = Math.pow(center.getYCoordinate(),2);
     z = Math.pow(center.getZCoordinate(),2);
     
     // set the distance equal to the square root of all the points squared
     distance = Math.sqrt(x+y+z);
     
     //return the distance rounded to the nearest integer
     return (int)distance;
  }
  
  /**
   * Abstract method to compute a shapes surface area
   * @return the surface area of a specific shape
   */
  public abstract double getSA();
  
  /**
   * Abstract method to comput a shapes volume
   * @return  the volume of a specific shape
   */
  public abstract double getVolume();
  
 
  /**
   * Implements the compareTo method of the Comparable Interface
   * @param comparedShape the shapre to be compared with 
   * @return the " natural order" of the objects
   */
  public int compareTo(Shape comparedShape) //compares the distance from center in descending order
  {
    
    // get the distance for the shape to be compared
    int compareDistance = ((Shape)comparedShape).DifferenceFromOrigin();
    
    
    // descending order. Will return negative is param - this = negative
    return compareDistance - this.DifferenceFromOrigin();
  }
  
  
  
  
  
}
