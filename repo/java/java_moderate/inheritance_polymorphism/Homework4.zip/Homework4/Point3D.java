/**
 *Created by Tiago Moore on Mar 23, 2014.
 *  Copyright (c) 2013 __TiagoMoore__. All rights reserved.
 * 
 */

/**
 * A class to represent a point in 3d space
 */
public class Point3D 
{
  
  // instance variables
  private double xCoordinate;
  private double yCoordinate;
  private double zCoordinate; 

  /**
   * Constructor initializes the coordinates
   */
  public Point3D(double x,double y, double z)
  {
    xCoordinate = x;
    yCoordinate = y;
    zCoordinate = z;
  }
  
  
  /**
   * Overrides toString method to return coordinates
   * @return  the coordinates of a 3d point in space 
   */
  public String toString()
  {
    return "Coordinates: "+xCoordinate+","+yCoordinate+","+zCoordinate+" ";
    
  }  
  
  // accessor methods
  
  /**
   * Gets the x coordinate of a point
   * @return the x coordinate of the point in space
   */
  public double getXCoordinate()
  {
    return xCoordinate ;
  }
  
 /**
   * Gets the y coordinate of a point
   * @return the y coordinate of the point in space
   */
  public double getYCoordinate()
  {
    return yCoordinate ;
  }
  
 /**
   * Gets the z coordinate of a point
   * @return the z coordinate of the point in space
   */
  public double getZCoordinate()
  {
    return zCoordinate ;
  }
  
 
}
