
import java.util.Comparator;


/**
 *Created by Tiago Moore on Mar 24, 2014.
 *  Copyright (c) 2013 __TiagoMoore__. All rights reserved.
 * 
 */

/**
 * A class to compare the volume of each shape
 * @author tmoore
 */
public class CompareShape implements Comparator<Shape>
{
  
  /**
   * An overriden compare method
   * @param s1 the first shape
   * @param s2 the second shape 
   * @return the difference in descending order , 
   * will return -1 if the first is smaller than second
   */
  public int compare(Shape s1, Shape s2)
  {
    double volume1 = s1.getVolume();// get volume of first shape
    double volume2 = s2.getVolume();// get volume of second shape
    
    return (int)(volume1-volume2); // return negative int if number is less that second
    
    // if v1 > v2 return 1 elif v1 > v2 return -1 else return 0 
  }
  
}
