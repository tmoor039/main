/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Created by Tiago Moore on Mar 23, 2014.
 * Copyright (c) 2013 __TiagoMoore__. All rights reserved.
 *
 */

/**
 * A parallelepiped class that extends a shape
 */
public class Parallelepiped extends Shape
{
  // additional instance variables
  private double length, width, height;

  /**
   * constructor
   * @param x the x coordinate
   * @param y the y coordinate
   * @param z the z coordinate
   * @param l the length of the box
   * @param w the width of the box
   * @param h the height of the box
   */
  public Parallelepiped(double x, double y, double z, double l, double w, double h)
  {
    super(x, y, z);
    length = l;
    width = w;
    height = h;
  }


  /**
   * Computs the surface area for the box
   * @return the surface area of the box
   */
  public double getSA()
  {
   return length*width;
  }


/**
 * Computs the volume of the box
 * @return the volume of the box.
 */
  public double getVolume()
  {
    return length*width*height;
  }


 /**
  * Prints all relevant data pertaining to the object by calling the superclass toString
  * @return  all shapes data
  */
  public String toString()
  {
    return "Parallelepiped with a center of " + super.toString() + ", Height: "
            + height + ", Length:  " + length + ", Width: " + width;
  }


}