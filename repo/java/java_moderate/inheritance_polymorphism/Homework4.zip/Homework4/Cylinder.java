
/**
 *Created by Tiago Moore on Mar 23, 2014.
 *  Copyright (c) 2013 __TiagoMoore__. All rights reserved.
 * 
 */

/**
 * A cylinder class to represent a shape
 */
public class Cylinder extends Shape
{
    // instance variables
    double radius, height;
    
    /**
     * Constructor creates a Cylinder Object
     * @param x the x coordinate    
     * @param y the y coordinate  
     * @param z the z coordinate
     * @param h the height
     * @param r the radius
     */
    public Cylinder(double x, double y, double z, double h, double r)
    {
      super(x, y, z);
      radius = r;
      height = h;     
    }

/**
 * Computes the surface area of a Cylinder 
 * @return the surface area of a cylinder
 */
  public double getSA()
  {

    return  2.0*Math.PI*Math.pow(radius, 2)+ 2.0*Math.PI*radius*height;
  }


/**
 * Computes the volume of a Cylinder
 * @return the volume of a Cylinder
 */
  public double getVolume()
  {

    return Math.PI*Math.pow(radius, 2)*height;
  }
  
  /**
   * Prints all relavant object data
   * @return  the object data
   */
  public String toString()
  {
    return "Cylinder with a center of "+super.toString()+ ", Height: " + height+", Radius:  "+radius;
            
  }
  

}
