/*------Start of header file-------*/

#include <linux/unistd.h>

#define __NR_sys_get_slob_amt_free	343
#define __NR_sys_get_slob_amt_claimed	344
#define __NR_sys_slob_user_alloc	345


extern long int _syscall(long int_sysno,...)__THROW;

/*-------End of header file--------*/

