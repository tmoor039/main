Office-hours program:

After extracting all the files in the same folder, just type
~$ Make and the Makefile will take care of compiling it.

Once it is finished compiling, ./office-hours to run the program.
If you pass no parameters for amount of students and office
capacity the program will inform you how its usage works.

Files necessary for compilation:
office-hours.c
office-hours.h
Makefile
