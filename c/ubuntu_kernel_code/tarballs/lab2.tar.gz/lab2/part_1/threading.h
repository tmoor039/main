/*---Start of header file------*/

#include<linux/unistd.h>

#define __NR_moore_borges 343

extern long int syscall (long int __sysno, ...) __THROW;

/*---End of header file--------*/

