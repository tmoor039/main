/*---Start of header file------*/

#include<linux/unistd.h>

#define __NR_tiago_moore 342

extern long int syscall (long int __sysno, ...) __THROW;

/*---End of header file--------*/
