/*---Start of C file------*/

#include<stdio.h>

#include "testmycall.h"

int main(void)

{

printf("%d\n", syscall(__NR_tiago_moore, 3656274));

}

/*---End of C file------*/
