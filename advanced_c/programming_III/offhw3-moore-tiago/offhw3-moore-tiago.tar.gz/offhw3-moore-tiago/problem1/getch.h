//
//  getch.h
//  offhandhw3problem1
//
//  Created by T Moore on 2/16/15.
//  Copyright (c) 2015 T Moore. All rights reserved.
//

#ifndef offhandhw3problem1_getch_h
#define offhandhw3problem1_getch_h


int etch(void);

void ngetch(int c);


#endif

