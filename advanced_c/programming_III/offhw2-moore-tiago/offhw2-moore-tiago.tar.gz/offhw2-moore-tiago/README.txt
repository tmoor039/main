To run my program, just rune the make file in the terminal.

with the command : make

Then you will run ./calc to execut the executable file which will run the Recursive calculator

for the second program, the function is not being tested in main; but the logic solves the problem asked 

